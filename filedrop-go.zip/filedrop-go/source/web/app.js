'use strict';
const $ = s => document.querySelector(s);
function el(tag, props, ...kids) {
  const n = document.createElement(tag);
  if (props) for (const [k, v] of Object.entries(props)) {
    if (k === 'class') n.className = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (v === true) n.setAttribute(k, '');
    else if (v !== false && v != null) n.setAttribute(k, v);
  }
  for (const c of kids.flat()) { if (c == null || c === false) continue; n.append(c.nodeType ? c : document.createTextNode(c)); }
  return n;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
const fmt = n => { const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; while (n >= 1024 && i < 4) { n /= 1024; i++; } return n.toFixed(i ? 1 : 0) + ' ' + u[i]; };

async function api(method, path, body) {
  const r = await fetch(path, {
    method, headers: method === 'GET' ? {} : { 'X-FD': '1', 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
  let j = null; try { j = await r.json(); } catch (e) { }
  if (!r.ok) throw Object.assign(new Error((j && j.error) || ('HTTP ' + r.status)), { status: r.status });
  return j;
}
function toast(m) { const t = $('#toast'); t.textContent = m; t.style.display = 'block'; clearTimeout(toast.t); toast.t = setTimeout(() => t.style.display = 'none', 3500); }

// ---- SHA-256 (WebCrypto, with a pure-JS fallback for non-secure contexts) ----
const sha256js = (() => {
  const K = [], H0 = []; let c = 0;
  const isP = x => { for (let i = 2; i * i <= x; i++) if (x % i === 0) return false; return true; };
  for (let n = 2; c < 64; n++) if (isP(n)) { if (c < 8) H0[c] = (Math.pow(n, 1 / 2) % 1) * 4294967296 | 0; K[c] = (Math.pow(n, 1 / 3) % 1) * 4294967296 | 0; c++; }
  const rr = (x, n) => (x >>> n) | (x << (32 - n));
  return u8 => {
    const l = u8.length, total = (((l + 8) >> 6) + 1) << 6, m = new Uint8Array(total);
    m.set(u8); m[l] = 0x80;
    const dv = new DataView(m.buffer);
    dv.setUint32(total - 8, Math.floor(l / 536870912)); dv.setUint32(total - 4, (l << 3) >>> 0);
    const h = H0.slice(), w = new Int32Array(64);
    for (let o = 0; o < total; o += 64) {
      for (let i = 0; i < 16; i++) w[i] = dv.getInt32(o + i * 4);
      for (let i = 16; i < 64; i++) {
        const a = w[i - 15], b = w[i - 2];
        w[i] = (w[i - 16] + (rr(a, 7) ^ rr(a, 18) ^ (a >>> 3)) + w[i - 7] + (rr(b, 17) ^ rr(b, 19) ^ (b >>> 10))) | 0;
      }
      let [a, b, c2, d, e, f, g, hh] = h;
      for (let i = 0; i < 64; i++) {
        const t1 = (hh + (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
        const t2 = ((rr(a, 2) ^ rr(a, 13) ^ rr(a, 22)) + ((a & b) ^ (a & c2) ^ (b & c2))) | 0;
        hh = g; g = f; f = e; e = (d + t1) | 0; d = c2; c2 = b; b = a; a = (t1 + t2) | 0;
      }
      h[0] = (h[0] + a) | 0; h[1] = (h[1] + b) | 0; h[2] = (h[2] + c2) | 0; h[3] = (h[3] + d) | 0;
      h[4] = (h[4] + e) | 0; h[5] = (h[5] + f) | 0; h[6] = (h[6] + g) | 0; h[7] = (h[7] + hh) | 0;
    }
    return h.map(x => (x >>> 0).toString(16).padStart(8, '0')).join('');
  };
})();
async function sha256hex(buf) {
  if (window.crypto && crypto.subtle) {
    const d = new Uint8Array(await crypto.subtle.digest('SHA-256', buf));
    return Array.from(d, b => b.toString(16).padStart(2, '0')).join('');
  }
  return sha256js(new Uint8Array(buf));
}
window.__sha256js = sha256js;

// ---- state ----
let snap = null, selected = null, es = null;
const files = new Map(), started = new Set(), dismissed = new Set(), speeds = new Map();

function deviceName() {
  const u = navigator.userAgent; let os = 'Device', br = '';
  if (/Android/.test(u)) os = 'Android'; else if (/iPhone|iPad|iPod/.test(u)) os = 'iOS';
  else if (/Windows/.test(u)) os = 'Windows'; else if (/Mac OS X|Macintosh/.test(u)) os = 'Mac';
  else if (/Linux|X11/.test(u)) os = 'Linux';
  if (/Edg\//.test(u)) br = 'Edge'; else if (/OPR\/|Opera/.test(u)) br = 'Opera';
  else if (/Firefox\/|FxiOS/.test(u)) br = 'Firefox'; else if (/Chrome\/|CriOS/.test(u)) br = 'Chrome';
  else if (/Safari\//.test(u)) br = 'Safari';
  return br ? os + ' \u00b7 ' + br : os;
}
function devIcon(name) { return /Android|iOS/.test(name) ? '\ud83d\udcf1' : '\ud83d\udcbb'; }

function showMsg(title, body, spin) {
  $('#main').hidden = true; $('#msgScreen').hidden = false;
  $('#msgTitle').textContent = title; $('#msgBody').textContent = body; $('#spin').hidden = !spin;
}
function showMain() { $('#msgScreen').hidden = true; $('#main').hidden = false; }

// ---- boot ----
async function boot() {
  let me = null;
  try { me = await api('GET', '/api/me'); }
  catch (e) { if (e.status !== 401) { showMsg('Cannot reach FileDrop', e.message); return; } }
  if (!me) {
    const hk = new URLSearchParams(location.search).get('k');
    const tok = (location.hash.match(/j=([0-9a-f]+)/) || [])[1];
    if (!hk && !tok) {
      showMsg('Not connected', 'Scan the QR code, or open the invite link shown on the host device. (On the host: use the link printed in the terminal.)');
      return;
    }
    try { await api('POST', '/api/join', { hostKey: hk || undefined, token: tok, name: deviceName() }); }
    catch (e) { showMsg('Cannot join', e.message); return; }
    history.replaceState(null, '', location.pathname);
  }
  startEvents();
}
function startEvents() {
  if (es) es.close();
  es = new EventSource('/api/events');
  es.onmessage = ev => render(JSON.parse(ev.data));
  es.onerror = async () => {
    try { await api('GET', '/api/me'); }
    catch (e) { if (e.status === 401) { es.close(); showMsg('Session ended', 'You were removed, or the host restarted. Scan the QR code again to rejoin.'); } }
  };
}

// ---- keyed list reconciliation (keeps buttons clickable while progress updates) ----
function reconcile(box, items, key, create, update) {
  const old = new Map([...box.children].map(c => [c.dataset.k, c]));
  items.forEach((it, i) => {
    const k = String(key(it)); let n = old.get(k);
    if (!n) { n = create(it); n.dataset.k = k; } else old.delete(k);
    update(n, it);
    const at = box.children[i];
    if (at !== n) box.insertBefore(n, at || null);
  });
  old.forEach(n => n.remove());
}

// ---- render ----
function render(s) {
  snap = s;
  if (s.me.status === 'pending') { showMsg('Waiting for the host', 'The host must tap Allow for "' + s.me.name + '" on their screen.', true); return; }
  if (s.me.status === 'denied') { showMsg('Request declined', 'The host did not allow this device.'); return; }
  showMain();
  $('#meName').textContent = s.me.name; $('#role').textContent = s.me.host ? 'Host' : 'Guest';
  $('#inviteCard').hidden = !s.me.host;
  if (s.me.host) renderInvite(s);
  renderPending(s); renderDevices(s); renderTransfers(s); renderMessages(s);
  for (const t of s.outgoing)
    if ((t.state === 'accepted' || t.state === 'active') && files.has(t.id) && !started.has(t.id)) { started.add(t.id); upload(t); }
}

function renderInvite(s) {
  const sel = $('#addrSel');
  const have = [...sel.options].map(o => o.value).join('|');
  if (have !== s.addrs.join('|')) { sel.replaceChildren(...s.addrs.map(a => el('option', { value: a }, a))); }
  $('#addrRow').hidden = s.addrs.length < 2;
  const addr = sel.value || s.addrs[0];
  const link = 'https://' + addr + '/#j=' + s.token;
  if ($('#link').value !== link) {
    $('#link').value = link;
    $('#qr').src = '/api/qr.png?addr=' + encodeURIComponent(addr) + '&v=' + s.token.slice(0, 8);
  }
  $('#fp').textContent = s.fp.match(/.{2}/g).slice(0, 12).join(':') + '...';
}

function renderPending(s) {
  $('#pendingCard').hidden = !(s.me.host && s.pending.length);
  reconcile($('#pendingList'), s.pending, p => p.id,
    p => { const n = el('div', { class: 'pend' }, el('div', { class: 'who' }, el('b', { class: 'pn' }), el('div', { class: 'mut small pi' })),
      el('button', { onclick: () => api('POST', '/api/approve', { id: p.id, allow: true }) }, 'Allow'),
      el('button', { class: 'bad', onclick: () => api('POST', '/api/approve', { id: p.id, allow: false }) }, 'Deny')); return n; },
    (n, p) => { n.querySelector('.pn').textContent = devIcon(p.name) + ' ' + p.name; n.querySelector('.pi').textContent = p.ip; });
}

function renderDevices(s) {
  const others = s.devices.filter(d => d.id !== s.me.id);
  if (selected && !others.some(d => d.id === selected)) selected = null;
  if (!selected && others.length === 1) selected = others[0].id;
  $('#devEmpty').hidden = others.length > 0;
  reconcile($('#devices'), others, d => d.id,
    d => {
      const kick = el('button', { class: 'small bad kick', title: 'Remove device', onclick: ev => { ev.stopPropagation(); if (confirm('Remove this device from the room?')) api('POST', '/api/kick', { id: d.id }); } }, '\u2715');
      return el('div', { class: 'dev', role: 'button', tabindex: '0', onclick: () => { selected = d.id; renderDevices(snap); } },
        el('span', { class: 'ico' }), el('span', {}, el('span', { class: 'dn' }), el('span', { class: 'ds' })), kick);
    },
    (n, d) => {
      n.classList.toggle('sel', d.id === selected);
      n.querySelector('.ico').textContent = devIcon(d.name);
      n.querySelector('.dn').textContent = d.name;
      n.querySelector('.ds').textContent = d.host ? 'host' : 'guest';
      n.querySelector('.kick').hidden = !(s.me.host && !d.host);
    });
  const target = others.find(d => d.id === selected);
  $('#sendTo').textContent = target ? 'Sending to: ' + target.name : (others.length ? 'Select a device above.' : 'Waiting for another device to join.');
  $('#drop').classList.toggle('disabled', !target);
  $('#sendTxt').disabled = !target;
}

function calcSpeed(id, bytes) {
  const now = performance.now(); let s = speeds.get(id);
  if (!s) { speeds.set(id, { t: now, b: bytes, v: 0 }); return 0; }
  const dt = now - s.t;
  if (dt >= 700) { const inst = (bytes - s.b) / (dt / 1000); s.v = s.v ? s.v * 0.6 + inst * 0.4 : inst; s.t = now; s.b = bytes; }
  return s.v;
}

function acceptOne(t) {
  const a = el('a', { href: '/api/t/' + t.id + '/dl', download: t.name, style: 'display:none' });
  document.body.append(a); a.click(); setTimeout(() => a.remove(), 1500);
}
function cancelT(t, reason) { return api('POST', '/api/t/' + t.id + '/cancel', reason ? { reason } : {}).catch(() => { }); }

function renderTransfers(s) {
  const list = [...s.incoming.map(t => ({ ...t, dir: 'in' })), ...s.outgoing.map(t => ({ ...t, dir: 'out' }))].filter(t => !dismissed.has(t.id));
  $('#trEmpty').hidden = list.length > 0;
  const offered = list.filter(t => t.dir === 'in' && t.state === 'offered');
  $('#acceptAll').hidden = offered.length < 2;
  $('#clearDone').hidden = !list.some(t => ['done', 'failed', 'declined', 'cancelled'].includes(t.state));
  reconcile($('#transfers'), list, t => t.id,
    t => el('div', { class: 'tr' },
      el('div', { class: 'top' }, el('span', { class: 'dir' }), el('span', { class: 'nm' }), el('span', { class: 'mut small sz' })),
      el('div', { class: 'bar' }, el('i')),
      el('div', { class: 'bot' }, el('span', { class: 'st' }), el('span', { class: 'acts' }))),
    (n, t) => {
      n._t = t;
      const pct = t.size ? Math.min(100, Math.floor(t.delivered / t.size * 100)) : (t.state === 'done' ? 100 : 0);
      n.querySelector('.dir').textContent = t.dir === 'in' ? '\u2b07' : '\u2b06';
      n.querySelector('.nm').textContent = t.name;
      n.querySelector('.nm').title = t.name;
      n.querySelector('.sz').textContent = fmt(t.size);
      n.querySelector('.bar i').style.width = pct + '%';
      n.classList.toggle('offer', t.dir === 'in' && t.state === 'offered');
      const run = t.state === 'accepted' || t.state === 'active';
      const sp = run ? calcSpeed(t.id, t.delivered) : 0;
      const prog = pct + '%' + (sp ? ' \u00b7 ' + fmt(sp) + '/s' : '');
      let txt = '', cls = 'mut';
      if (t.dir === 'out') {
        if (t.state === 'offered') { txt = 'Waiting for ' + t.peer + ' to accept\u2026'; cls = 'wait'; }
        else if (run) txt = 'Sending to ' + t.peer + ' \u00b7 ' + prog;
        else if (t.state === 'done') { txt = 'Delivered to ' + t.peer + ' \u2713 verified'; cls = 'ok'; }
        else if (t.state === 'declined') { txt = t.peer + ' declined'; cls = 'err'; }
        else { txt = (t.state === 'failed' ? 'Failed: ' : '') + (t.err || t.state); cls = 'err'; }
      } else {
        if (t.state === 'offered') { txt = t.peer + ' wants to send you this file'; cls = 'wait'; }
        else if (run) txt = 'Receiving from ' + t.peer + ' \u00b7 ' + prog;
        else if (t.state === 'done') { txt = 'Saved to your Downloads \u2713 SHA-256 ' + t.sha.slice(0, 16) + '\u2026'; cls = 'ok'; }
        else if (t.state === 'declined') { txt = 'Declined'; cls = 'err'; }
        else { txt = (t.state === 'failed' ? 'Failed: ' : '') + (t.err || t.state); cls = 'err'; }
      }
      const st = n.querySelector('.st'); st.textContent = txt; st.className = 'st ' + cls;
      const sig = t.dir + t.state;
      if (n._sig !== sig) {
        n._sig = sig;
        const acts = n.querySelector('.acts'); acts.replaceChildren();
        if (t.dir === 'in' && t.state === 'offered') {
          acts.append(el('button', { class: 'small', onclick: () => acceptOne(n._t) }, 'Accept'),
            el('button', { class: 'small bad', onclick: () => api('POST', '/api/t/' + n._t.id + '/decline') }, 'Decline'));
        } else if (t.state === 'offered' || run) {
          acts.append(el('button', { class: 'small bad', onclick: () => cancelT(n._t) }, 'Cancel'));
        } else {
          acts.append(el('button', { class: 'small ghost', onclick: () => { dismissed.add(n._t.id); n.remove(); } }, 'Dismiss'));
        }
      }
    });
}

function renderMessages(s) {
  $('#msgCard').hidden = s.messages.length === 0;
  reconcile($('#msgs'), s.messages, m => m.at + ':' + m.from, m => {
    const body = el('div', { class: 'body' });
    const box = el('div', { class: 'msg' }, el('div', { class: 'from' }), body, el('div', { class: 'row', style: 'margin-top:0' }));
    return box;
  }, (n, m) => {
    n.querySelector('.from').textContent = 'From ' + m.from + ' \u00b7 ' + new Date(m.at).toLocaleTimeString();
    n.querySelector('.body').textContent = m.text;
    if (!n._init) {
      n._init = true;
      const row = n.querySelector('.row');
      row.append(el('button', { class: 'small ghost', onclick: () => copyText(m.text) }, 'Copy'));
      if (/^https?:\/\/\S+$/i.test(m.text.trim()))
        row.append(el('a', { href: m.text.trim(), target: '_blank', rel: 'noopener noreferrer' }, el('button', { class: 'small ghost' }, 'Open')));
    }
  });
}
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast('Copied'); }
  catch (e) {
    const ta = el('textarea', { style: 'position:fixed;opacity:0' }); ta.value = t; document.body.append(ta); ta.select();
    try { document.execCommand('copy'); toast('Copied'); } catch (_) { toast('Copy failed'); } ta.remove();
  }
}

// ---- sending ----
async function sendFiles(list) {
  if (!selected) { toast('Pick a device first'); return; }
  const arr = [...list].filter(f => f.size > 0 || f.name);
  if (!arr.length) return;
  try {
    const r = await api('POST', '/api/offer', { to: selected, files: arr.map(f => ({ name: f.name, size: f.size })) });
    r.transfers.forEach((t, i) => files.set(t.id, arr[i]));
  } catch (e) { toast(e.message); }
}

async function upload(t) {
  const f = files.get(t.id), CH = snap.chunk, total = Math.ceil(f.size / CH);
  let nextIdx = 0, failed = null;
  async function worker() {
    while (nextIdx < total && !failed) {
      const i = nextIdx++;
      let buf;
      try { buf = await f.slice(i * CH, Math.min(f.size, (i + 1) * CH)).arrayBuffer(); }
      catch (e) { failed = 'could not read file: ' + e.message; return; }
      const hash = await sha256hex(buf);
      for (let a = 0; ; a++) {
        let r;
        try { r = await fetch('/api/t/' + t.id + '/chunk?i=' + i, { method: 'PUT', headers: { 'X-FD': '1', 'X-Sha256': hash }, body: buf }); }
        catch (e) { if (a >= 3) { failed = 'connection lost'; return; } await sleep(800); continue; }
        if (r.ok) break;
        let msg = 'upload error ' + r.status; try { msg = (await r.json()).error || msg; } catch (e) { }
        if (r.status === 422 && a < 3) continue; // corrupted in transit: resend
        if (r.status >= 500 && a < 3) { await sleep(800); continue; }
        failed = msg; return;
      }
    }
  }
  await Promise.all([worker(), worker()]);
  if (failed) { await cancelT(t, 'upload failed: ' + failed); }
  files.delete(t.id);
}

// ---- wiring ----
const drop = $('#drop'), fi = $('#file');
drop.addEventListener('click', () => { if (!drop.classList.contains('disabled')) fi.click(); else toast('Pick a device first'); });
fi.addEventListener('change', () => { sendFiles(fi.files); fi.value = ''; });
['dragover', 'dragenter'].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); if (!drop.classList.contains('disabled')) drop.classList.add('over'); }));
['dragleave', 'drop'].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', ev => sendFiles(ev.dataTransfer.files));
$('#sendTxt').addEventListener('click', async () => {
  const text = $('#txt').value; if (!text.trim()) return;
  try { await api('POST', '/api/text', { to: selected, text }); $('#txt').value = ''; toast('Sent'); } catch (e) { toast(e.message); }
});
$('#acceptAll').addEventListener('click', () => {
  const list = snap.incoming.filter(t => t.state === 'offered');
  list.forEach((t, i) => setTimeout(() => acceptOne(t), i * 350));
});
$('#clearDone').addEventListener('click', () => {
  [...snap.incoming, ...snap.outgoing].filter(t => ['done', 'failed', 'declined', 'cancelled'].includes(t.state)).forEach(t => dismissed.add(t.id));
  renderTransfers(snap);
});
$('#clearMsgs').addEventListener('click', () => api('POST', '/api/messages/clear'));
$('#copyLink').addEventListener('click', () => copyText($('#link').value));
$('#rotate').addEventListener('click', async () => { await api('POST', '/api/rotate'); toast('New invite link created'); });
$('#addrSel').addEventListener('change', () => { $('#link').value = ''; renderInvite(snap); });

boot();

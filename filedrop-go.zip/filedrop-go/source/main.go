// FileDrop - host it on any device; others join by link or QR code and
// exchange files / text directly through their browsers. One static binary,
// no installs needed on the other devices.
//
//	Security : TLS 1.2+, 128-bit join secret, host approval for every device,
//	           receiver must accept every file, per-chunk SHA-256, strict sizes.
//	Speed    : streaming relay with back-pressure (no temp files, any file size).
package main

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"embed"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"errors"
	"flag"
	"fmt"
	"io"
	"io/fs"
	"log"
	"math/big"
	"mime"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	qrcode "github.com/skip2/go-qrcode"
)

//go:embed web/*
var webFS embed.FS

const (
	chunkSize = 4 << 20 // bytes per chunk (announced to browsers)
	window    = 8       // max chunks buffered per transfer (back-pressure)
	idleLimit = 90 * time.Second
)

// ------------------------------------------------------------------ types --

type Message struct {
	From string `json:"from"`
	Text string `json:"text"`
	At   int64  `json:"at"`
}

type Session struct {
	Secret, ID, Name, IP string
	Host                 bool
	Status               string // pending | approved | denied
	Created, LastSeen    time.Time
	subs                 int
	Messages             []Message
}

type Transfer struct {
	ID, From, To, FromName, ToName, Name string
	Size                                 int64
	Total                                int
	State, Err, SHA                      string // offered|accepted|active|done|failed|declined|cancelled
	Created, Ended                       time.Time
	dlStarted                            bool
	delivered, last                      atomic.Int64

	mu     sync.Mutex
	cond   *sync.Cond
	chunks map[int][]byte
	next   int
	dead   bool
}

func (t *Transfer) touch()              { t.last.Store(time.Now().UnixNano()) }
func (t *Transfer) lastTime() time.Time { return time.Unix(0, t.last.Load()) }
func (t *Transfer) wake()               { t.mu.Lock(); t.cond.Broadcast(); t.mu.Unlock() }

type failRec struct {
	n     int
	until time.Time
}

type Hub struct {
	mu        sync.Mutex
	sessions  map[string]*Session
	transfers map[string]*Transfer
	token     string
	hostKey   string
	hostName  string
	addrs     []string
	fp        string

	fmu   sync.Mutex
	fails map[string]*failRec
}

// ---------------------------------------------------------------- helpers --

func randHex(n int) string {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return hex.EncodeToString(b)
}

func eq(a, b string) bool { return subtle.ConstantTimeCompare([]byte(a), []byte(b)) == 1 }

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}
func jsonErr(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]string{"error": msg})
}
func readJSON(w http.ResponseWriter, r *http.Request, v any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
	if err := json.NewDecoder(r.Body).Decode(v); err != nil {
		jsonErr(w, 400, "bad request")
		return false
	}
	return true
}

func clientIP(r *http.Request) string {
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return h
}

func cleanName(s string, max int, fallback string) string {
	s = strings.Map(func(r rune) rune {
		if r < 32 || r == 127 {
			return -1
		}
		return r
	}, s)
	s = strings.TrimSpace(s)
	if rs := []rune(s); len(rs) > max {
		s = string(rs[:max])
	}
	if s == "" {
		return fallback
	}
	return s
}

func cleanFile(s string) string {
	s = strings.ReplaceAll(s, "\\", "/")
	if i := strings.LastIndex(s, "/"); i >= 0 {
		s = s[i+1:]
	}
	s = strings.Map(func(r rune) rune {
		if r < 32 || r == 127 || strings.ContainsRune(`<>:"|?*`, r) {
			return '_'
		}
		return r
	}, s)
	s = strings.Trim(strings.TrimSpace(s), ". ")
	if rs := []rune(s); len(rs) > 200 {
		s = string(rs[:200])
	}
	if s == "" {
		return "file"
	}
	return s
}

func (h *Hub) blocked(ip string) bool {
	h.fmu.Lock()
	defer h.fmu.Unlock()
	f := h.fails[ip]
	return f != nil && time.Now().Before(f.until)
}
func (h *Hub) noteFail(ip string) {
	h.fmu.Lock()
	defer h.fmu.Unlock()
	f := h.fails[ip]
	if f == nil {
		f = &failRec{}
		h.fails[ip] = f
	}
	if f.n++; f.n >= 8 {
		f.n, f.until = 0, time.Now().Add(5*time.Minute)
	}
}

func (h *Hub) cookieName(r *http.Request) string {
	if a, ok := r.Context().Value(http.LocalAddrContextKey).(net.Addr); ok {
		if _, p, err := net.SplitHostPort(a.String()); err == nil {
			return "fd" + p
		}
	}
	return "fd"
}

func (h *Hub) auth(r *http.Request) *Session {
	c, err := r.Cookie(h.cookieName(r))
	if err != nil {
		return nil
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	s := h.sessions[c.Value]
	if s != nil {
		s.LastSeen = time.Now()
	}
	return s
}

func (h *Hub) approved(w http.ResponseWriter, r *http.Request) *Session {
	s := h.auth(r)
	if s == nil {
		jsonErr(w, 401, "not signed in")
		return nil
	}
	h.mu.Lock()
	st := s.Status
	h.mu.Unlock()
	if st != "approved" {
		jsonErr(w, 403, "waiting for approval")
		return nil
	}
	return s
}

func (h *Hub) hostOnly(w http.ResponseWriter, r *http.Request) *Session {
	s := h.approved(w, r)
	if s != nil && !s.Host {
		jsonErr(w, 403, "host only")
		return nil
	}
	return s
}

func (h *Hub) byID(id string) *Session { // caller holds h.mu
	for _, s := range h.sessions {
		if s.ID == id {
			return s
		}
	}
	return nil
}

func (h *Hub) uniqueName(base string, self *Session) string { // caller holds h.mu
	taken := func(n string) bool {
		for _, s := range h.sessions {
			if s != self && s.Name == n {
				return true
			}
		}
		return false
	}
	n := base
	for i := 2; taken(n); i++ {
		n = fmt.Sprintf("%s (%d)", base, i)
	}
	return n
}

func (h *Hub) getTransfer(id string) *Transfer {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.transfers[id]
}

func (h *Hub) finish(t *Transfer, state, msg, sha string) {
	h.mu.Lock()
	switch t.State {
	case "done", "failed", "declined", "cancelled":
		h.mu.Unlock()
		return
	}
	t.State, t.Err, t.SHA, t.Ended = state, msg, sha, time.Now()
	h.mu.Unlock()
	t.mu.Lock()
	t.dead, t.chunks = true, nil
	t.cond.Broadcast()
	t.mu.Unlock()
}

func terminal(state string) bool {
	return state == "done" || state == "failed" || state == "declined" || state == "cancelled"
}

// ------------------------------------------------------- join / approval --

func (h *Hub) join(w http.ResponseWriter, r *http.Request) {
	ip := clientIP(r)
	if h.blocked(ip) {
		jsonErr(w, 429, "too many attempts - wait a few minutes")
		return
	}
	var req struct{ Token, HostKey, Name string }
	if !readJSON(w, r, &req) {
		return
	}
	now := time.Now()
	s := &Session{Secret: randHex(32), ID: randHex(5), IP: ip, Created: now, LastSeen: now}
	if req.HostKey != "" {
		if !net.ParseIP(ip).IsLoopback() || !eq(req.HostKey, h.hostKey) {
			h.noteFail(ip)
			jsonErr(w, 403, "invalid host key")
			return
		}
		s.Host, s.Status, s.Name = true, "approved", h.hostName
	} else {
		h.mu.Lock()
		ok := eq(req.Token, h.token)
		h.mu.Unlock()
		if !ok {
			h.noteFail(ip)
			jsonErr(w, 403, "this invite link is invalid or has expired")
			return
		}
		s.Status, s.Name = "pending", cleanName(req.Name, 40, "Device")
	}
	h.mu.Lock()
	pending := 0
	for _, o := range h.sessions {
		if o.Status == "pending" {
			pending++
		}
	}
	if pending >= 20 || len(h.sessions) >= 100 {
		h.mu.Unlock()
		jsonErr(w, 429, "room is busy")
		return
	}
	if s.Host {
		for k, o := range h.sessions {
			if o.Host {
				delete(h.sessions, k)
			}
		}
	}
	s.Name = h.uniqueName(s.Name, s)
	h.sessions[s.Secret] = s
	h.mu.Unlock()
	http.SetCookie(w, &http.Cookie{Name: h.cookieName(r), Value: s.Secret, Path: "/", HttpOnly: true,
		SameSite: http.SameSiteStrictMode, Secure: r.TLS != nil, MaxAge: 86400})
	writeJSON(w, 200, map[string]any{"id": s.ID, "status": s.Status})
}

func (h *Hub) me(w http.ResponseWriter, r *http.Request) {
	s := h.auth(r)
	if s == nil {
		jsonErr(w, 401, "not signed in")
		return
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	writeJSON(w, 200, map[string]any{"id": s.ID, "name": s.Name, "host": s.Host, "status": s.Status})
}

func (h *Hub) approve(w http.ResponseWriter, r *http.Request) {
	if h.hostOnly(w, r) == nil {
		return
	}
	var req struct {
		ID    string
		Allow bool
	}
	if !readJSON(w, r, &req) {
		return
	}
	h.mu.Lock()
	if s := h.byID(req.ID); s != nil && s.Status == "pending" {
		if req.Allow {
			s.Status = "approved"
		} else {
			s.Status = "denied"
		}
	}
	h.mu.Unlock()
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (h *Hub) kick(w http.ResponseWriter, r *http.Request) {
	me := h.hostOnly(w, r)
	if me == nil {
		return
	}
	var req struct{ ID string }
	if !readJSON(w, r, &req) {
		return
	}
	var kill []*Transfer
	h.mu.Lock()
	if s := h.byID(req.ID); s != nil && !s.Host {
		delete(h.sessions, s.Secret)
		for _, t := range h.transfers {
			if (t.From == s.ID || t.To == s.ID) && !terminal(t.State) {
				kill = append(kill, t)
			}
		}
	}
	h.mu.Unlock()
	for _, t := range kill {
		h.finish(t, "failed", "device was removed by the host", "")
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (h *Hub) rotate(w http.ResponseWriter, r *http.Request) {
	if h.hostOnly(w, r) == nil {
		return
	}
	h.mu.Lock()
	h.token = randHex(16)
	h.mu.Unlock()
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (h *Hub) qr(w http.ResponseWriter, r *http.Request) {
	if h.hostOnly(w, r) == nil {
		return
	}
	addr := r.URL.Query().Get("addr")
	valid := false
	for _, a := range h.addrs {
		if a == addr {
			valid = true
		}
	}
	if !valid {
		addr = h.addrs[0]
	}
	h.mu.Lock()
	link := "https://" + addr + "/#j=" + h.token
	h.mu.Unlock()
	png, err := qrcode.Encode(link, qrcode.Medium, 480)
	if err != nil {
		jsonErr(w, 500, "qr failed")
		return
	}
	w.Header().Set("Content-Type", "image/png")
	w.Write(png)
}

// --------------------------------------------------------------- snapshot --

type SnapMe struct {
	ID     string `json:"id"`
	Name   string `json:"name"`
	Host   bool   `json:"host"`
	Status string `json:"status"`
}
type SnapDev struct {
	ID   string `json:"id"`
	Name string `json:"name"`
	Host bool   `json:"host"`
}
type SnapPending struct {
	ID   string `json:"id"`
	Name string `json:"name"`
	IP   string `json:"ip"`
}
type SnapTransfer struct {
	ID        string `json:"id"`
	Peer      string `json:"peer"`
	Name      string `json:"name"`
	Size      int64  `json:"size"`
	Delivered int64  `json:"delivered"`
	State     string `json:"state"`
	Err       string `json:"err,omitempty"`
	SHA       string `json:"sha,omitempty"`
}
type Snap struct {
	Me       SnapMe         `json:"me"`
	Devices  []SnapDev      `json:"devices"`
	Pending  []SnapPending  `json:"pending"`
	Incoming []SnapTransfer `json:"incoming"`
	Outgoing []SnapTransfer `json:"outgoing"`
	Messages []Message      `json:"messages"`
	Addrs    []string       `json:"addrs,omitempty"`
	Token    string         `json:"token,omitempty"`
	Fp       string         `json:"fp"`
	Chunk    int64          `json:"chunk"`
}

func (h *Hub) snapshot(s *Session) (*Snap, bool) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if h.sessions[s.Secret] != s {
		return nil, false
	}
	sn := &Snap{Devices: []SnapDev{}, Pending: []SnapPending{}, Incoming: []SnapTransfer{},
		Outgoing: []SnapTransfer{}, Messages: []Message{}, Fp: h.fp, Chunk: chunkSize}
	sn.Me = SnapMe{s.ID, s.Name, s.Host, s.Status}
	if s.Status != "approved" {
		return sn, true
	}
	var pend []*Session
	for _, o := range h.sessions {
		switch {
		case o.Status == "approved" && o.subs > 0:
			sn.Devices = append(sn.Devices, SnapDev{o.ID, o.Name, o.Host})
		case o.Status == "pending" && s.Host:
			pend = append(pend, o)
		}
	}
	sort.Slice(sn.Devices, func(i, j int) bool {
		a, b := sn.Devices[i], sn.Devices[j]
		if a.Host != b.Host {
			return a.Host
		}
		if a.Name != b.Name {
			return a.Name < b.Name
		}
		return a.ID < b.ID
	})
	sort.Slice(pend, func(i, j int) bool { return pend[i].Created.Before(pend[j].Created) })
	for _, o := range pend {
		sn.Pending = append(sn.Pending, SnapPending{o.ID, o.Name, o.IP})
	}
	var ts []*Transfer
	for _, t := range h.transfers {
		if t.From == s.ID || t.To == s.ID {
			ts = append(ts, t)
		}
	}
	sort.Slice(ts, func(i, j int) bool {
		if !ts[i].Created.Equal(ts[j].Created) {
			return ts[i].Created.Before(ts[j].Created)
		}
		return ts[i].ID < ts[j].ID
	})
	for _, t := range ts {
		st := SnapTransfer{ID: t.ID, Name: t.Name, Size: t.Size, Delivered: t.delivered.Load(),
			State: t.State, Err: t.Err, SHA: t.SHA}
		if t.To == s.ID {
			st.Peer = t.FromName
			sn.Incoming = append(sn.Incoming, st)
		} else {
			st.Peer = t.ToName
			sn.Outgoing = append(sn.Outgoing, st)
		}
	}
	sn.Messages = append(sn.Messages, s.Messages...)
	if s.Host {
		sn.Addrs, sn.Token = h.addrs, h.token
	}
	return sn, true
}

func (h *Hub) events(w http.ResponseWriter, r *http.Request) {
	s := h.auth(r)
	if s == nil {
		jsonErr(w, 401, "not signed in")
		return
	}
	fl, ok := w.(http.Flusher)
	if !ok {
		jsonErr(w, 500, "streaming unsupported")
		return
	}
	hd := w.Header()
	hd.Set("Content-Type", "text/event-stream")
	hd.Set("X-Accel-Buffering", "no")
	w.WriteHeader(200)
	h.mu.Lock()
	s.subs++
	h.mu.Unlock()
	defer func() { h.mu.Lock(); s.subs--; h.mu.Unlock() }()

	tick := time.NewTicker(250 * time.Millisecond)
	defer tick.Stop()
	var last []byte
	lastWrite := time.Now()
	for {
		select {
		case <-r.Context().Done():
			return
		case <-tick.C:
			sn, alive := h.snapshot(s)
			if !alive {
				return
			}
			b, _ := json.Marshal(sn)
			var err error
			if !bytes.Equal(b, last) {
				_, err = fmt.Fprintf(w, "data: %s\n\n", b)
				last, lastWrite = b, time.Now()
			} else if time.Since(lastWrite) > 15*time.Second {
				_, err = io.WriteString(w, ": ka\n\n")
				lastWrite = time.Now()
			} else {
				continue
			}
			if err != nil {
				return
			}
			fl.Flush()
		}
	}
}

// --------------------------------------------------------------- transfers --

func (h *Hub) offer(w http.ResponseWriter, r *http.Request) {
	s := h.approved(w, r)
	if s == nil {
		return
	}
	var req struct {
		To    string
		Files []struct {
			Name string
			Size int64
		}
	}
	if !readJSON(w, r, &req) {
		return
	}
	if len(req.Files) == 0 || len(req.Files) > 200 {
		jsonErr(w, 400, "choose between 1 and 200 files")
		return
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	to := h.byID(req.To)
	if to == nil || to.Status != "approved" || to.subs == 0 || to.ID == s.ID {
		jsonErr(w, 404, "that device is not available")
		return
	}
	if len(h.transfers) > 1000 {
		jsonErr(w, 429, "too many transfers")
		return
	}
	out := make([]map[string]any, 0, len(req.Files))
	now := time.Now()
	for _, f := range req.Files {
		if f.Size < 0 {
			jsonErr(w, 400, "bad file size")
			return
		}
		t := &Transfer{ID: randHex(16), From: s.ID, To: to.ID, FromName: s.Name, ToName: to.Name,
			Name: cleanFile(f.Name), Size: f.Size, Total: int((f.Size + chunkSize - 1) / chunkSize),
			State: "offered", Created: now, chunks: map[int][]byte{}}
		t.cond = sync.NewCond(&t.mu)
		t.touch()
		h.transfers[t.ID] = t
		out = append(out, map[string]any{"id": t.ID, "name": t.Name, "size": t.Size})
	}
	writeJSON(w, 200, map[string]any{"transfers": out})
}

func (h *Hub) decline(w http.ResponseWriter, r *http.Request) {
	s := h.approved(w, r)
	if s == nil {
		return
	}
	t := h.getTransfer(r.PathValue("id"))
	if t == nil || t.To != s.ID {
		jsonErr(w, 404, "no such transfer")
		return
	}
	h.mu.Lock()
	ok := t.State == "offered"
	h.mu.Unlock()
	if ok {
		h.finish(t, "declined", "", "")
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (h *Hub) cancel(w http.ResponseWriter, r *http.Request) {
	s := h.approved(w, r)
	if s == nil {
		return
	}
	t := h.getTransfer(r.PathValue("id"))
	if t == nil || (t.To != s.ID && t.From != s.ID) {
		jsonErr(w, 404, "no such transfer")
		return
	}
	var req struct{ Reason string }
	json.NewDecoder(io.LimitReader(r.Body, 4096)).Decode(&req)
	msg := "cancelled by " + s.Name
	if req.Reason != "" {
		msg = cleanName(req.Reason, 120, msg)
	}
	h.finish(t, "cancelled", msg, "")
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (h *Hub) putChunk(w http.ResponseWriter, r *http.Request) {
	s := h.approved(w, r)
	if s == nil {
		return
	}
	t := h.getTransfer(r.PathValue("id"))
	if t == nil || t.From != s.ID {
		jsonErr(w, 404, "no such transfer")
		return
	}
	i, err := strconv.Atoi(r.URL.Query().Get("i"))
	if err != nil || i < 0 || i >= t.Total {
		jsonErr(w, 400, "bad chunk index")
		return
	}
	want := int64(chunkSize)
	if i == t.Total-1 {
		want = t.Size - int64(t.Total-1)*chunkSize
	}
	if r.ContentLength != want {
		jsonErr(w, 400, "bad chunk length")
		return
	}
	h.mu.Lock()
	st := t.State
	h.mu.Unlock()
	if st != "accepted" && st != "active" {
		jsonErr(w, 409, "transfer is "+st)
		return
	}
	data := make([]byte, want)
	if _, err := io.ReadFull(r.Body, data); err != nil {
		jsonErr(w, 400, "short chunk")
		return
	}
	sum := sha256.Sum256(data)
	if !strings.EqualFold(hex.EncodeToString(sum[:]), r.Header.Get("X-Sha256")) {
		jsonErr(w, 422, "chunk checksum mismatch")
		return
	}
	stop := context.AfterFunc(r.Context(), t.wake)
	defer stop()
	t.mu.Lock()
	for !t.dead && i >= t.next+window && r.Context().Err() == nil {
		t.cond.Wait() // back-pressure: wait for the receiver to catch up
	}
	if t.dead || r.Context().Err() != nil {
		t.mu.Unlock()
		jsonErr(w, 409, "transfer ended")
		return
	}
	if i >= t.next {
		t.chunks[i] = data
		t.cond.Broadcast()
	}
	t.mu.Unlock()
	t.touch()
	h.mu.Lock()
	if t.State == "accepted" {
		t.State = "active"
	}
	h.mu.Unlock()
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (t *Transfer) waitChunk(ctx context.Context, i int) ([]byte, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	for {
		if t.dead {
			return nil, errors.New("transfer ended")
		}
		if d, ok := t.chunks[i]; ok {
			delete(t.chunks, i)
			t.next = i + 1
			t.cond.Broadcast()
			return d, nil
		}
		if ctx.Err() != nil {
			return nil, errors.New("receiver disconnected")
		}
		if time.Since(t.lastTime()) > idleLimit {
			return nil, errors.New("sender stopped sending (timed out)")
		}
		t.cond.Wait()
	}
}

func (h *Hub) download(w http.ResponseWriter, r *http.Request) {
	s := h.approved(w, r)
	if s == nil {
		return
	}
	t := h.getTransfer(r.PathValue("id"))
	if t == nil || t.To != s.ID {
		jsonErr(w, 404, "no such transfer")
		return
	}
	h.mu.Lock()
	if (t.State != "offered" && t.State != "accepted") || t.dlStarted {
		h.mu.Unlock()
		jsonErr(w, 409, "transfer not available")
		return
	}
	t.State, t.dlStarted = "accepted", true // opening the download == accepting
	h.mu.Unlock()
	t.touch()

	hd := w.Header()
	hd.Set("Content-Type", "application/octet-stream")
	if cd := mime.FormatMediaType("attachment", map[string]string{"filename": t.Name}); cd != "" {
		hd.Set("Content-Disposition", cd)
	} else {
		hd.Set("Content-Disposition", "attachment")
	}
	hd.Set("Content-Length", strconv.FormatInt(t.Size, 10))
	hd.Set("Accept-Ranges", "none")
	w.WriteHeader(200)
	rc := http.NewResponseController(w)
	rc.Flush() // send headers now so the browser shows the download (with its size) immediately

	stopTick := make(chan struct{})
	defer close(stopTick)
	go func() {
		tk := time.NewTicker(2 * time.Second)
		defer tk.Stop()
		for {
			select {
			case <-stopTick:
				return
			case <-tk.C:
				t.wake()
			}
		}
	}()
	stop := context.AfterFunc(r.Context(), t.wake)
	defer stop()

	hasher := sha256.New()
	for i := 0; i < t.Total; i++ {
		data, err := t.waitChunk(r.Context(), i)
		if err != nil {
			h.finish(t, "failed", err.Error(), "")
			panic(http.ErrAbortHandler) // cut the connection so the browser marks the download as failed
		}
		rc.SetWriteDeadline(time.Now().Add(2 * time.Minute))
		if _, err := w.Write(data); err != nil {
			h.finish(t, "failed", "receiver connection lost", "")
			return
		}
		hasher.Write(data)
		t.delivered.Add(int64(len(data)))
		t.touch()
		rc.Flush()
	}
	h.finish(t, "done", "", hex.EncodeToString(hasher.Sum(nil)))
}

// ---------------------------------------------------------------- messages --

func (h *Hub) text(w http.ResponseWriter, r *http.Request) {
	s := h.approved(w, r)
	if s == nil {
		return
	}
	var req struct{ To, Text string }
	if !readJSON(w, r, &req) {
		return
	}
	if strings.TrimSpace(req.Text) == "" || len(req.Text) > 64*1024 {
		jsonErr(w, 400, "message must be 1 - 65536 bytes")
		return
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	to := h.byID(req.To)
	if to == nil || to.Status != "approved" || to.subs == 0 || to.ID == s.ID {
		jsonErr(w, 404, "that device is not available")
		return
	}
	to.Messages = append(to.Messages, Message{From: s.Name, Text: req.Text, At: time.Now().UnixMilli()})
	if len(to.Messages) > 50 {
		to.Messages = to.Messages[len(to.Messages)-50:]
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (h *Hub) clearMessages(w http.ResponseWriter, r *http.Request) {
	s := h.approved(w, r)
	if s == nil {
		return
	}
	h.mu.Lock()
	s.Messages = nil
	h.mu.Unlock()
	writeJSON(w, 200, map[string]bool{"ok": true})
}

// ---------------------------------------------------------------- watchdog --

func (h *Hub) watchdog() {
	for range time.Tick(time.Second) {
		now := time.Now()
		type kill struct {
			t   *Transfer
			why string
		}
		var kills []kill
		h.mu.Lock()
		for id, t := range h.transfers {
			switch t.State {
			case "offered":
				if now.Sub(t.Created) > 2*time.Minute {
					kills = append(kills, kill{t, "no response from " + t.ToName})
				}
			case "accepted", "active":
				if now.Sub(t.lastTime()) > idleLimit {
					kills = append(kills, kill{t, "timed out - no data for 90 seconds"})
				}
			default:
				if now.Sub(t.Ended) > 10*time.Minute {
					delete(h.transfers, id)
				}
			}
		}
		for k, s := range h.sessions {
			if (s.Status != "approved" && now.Sub(s.Created) > 10*time.Minute) ||
				(s.subs == 0 && now.Sub(s.LastSeen) > 24*time.Hour) {
				delete(h.sessions, k)
			}
		}
		h.mu.Unlock()
		for _, k := range kills {
			h.finish(k.t, "failed", k.why, "")
		}
	}
}

// -------------------------------------------------------------- middleware --

func secure(next http.Handler, loopbackPort int) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		hd := w.Header()
		hd.Set("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
		hd.Set("X-Content-Type-Options", "nosniff")
		hd.Set("X-Frame-Options", "DENY")
		hd.Set("Referrer-Policy", "no-referrer")
		hd.Set("Cache-Control", "no-store")
		if loopbackPort > 0 { // blocks DNS-rebinding against the local-only listener
			p := strconv.Itoa(loopbackPort)
			if r.Host != "127.0.0.1:"+p && r.Host != "localhost:"+p {
				http.Error(w, "forbidden", 403)
				return
			}
		}
		if r.Method != "GET" && r.Method != "HEAD" && r.Header.Get("X-FD") != "1" {
			jsonErr(w, 403, "missing X-FD header")
			return
		}
		next.ServeHTTP(w, r)
	})
}

// --------------------------------------------------------------- TLS cert --

func configDir() string {
	d, err := os.UserConfigDir()
	if err != nil || d == "" {
		d = os.TempDir()
	}
	return filepath.Join(d, "filedrop")
}

func loadOrCreateCert(ips []net.IP) (tls.Certificate, error) {
	dir := configDir()
	os.MkdirAll(dir, 0o700)
	crtPath, keyPath := filepath.Join(dir, "cert.pem"), filepath.Join(dir, "key.pem")
	if c, err := tls.LoadX509KeyPair(crtPath, keyPath); err == nil {
		if leaf, err := x509.ParseCertificate(c.Certificate[0]); err == nil &&
			time.Now().Add(48*time.Hour).Before(leaf.NotAfter) {
			covered := true
			for _, ip := range ips {
				ok := false
				for _, cip := range leaf.IPAddresses {
					ok = ok || cip.Equal(ip)
				}
				covered = covered && ok
			}
			if covered {
				c.Leaf = leaf
				return c, nil
			}
		}
	}
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return tls.Certificate{}, err
	}
	serial, _ := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 120))
	now := time.Now()
	tmpl := x509.Certificate{
		SerialNumber: serial, Subject: pkix.Name{CommonName: "FileDrop", Organization: []string{"FileDrop"}},
		NotBefore: now.Add(-time.Hour), NotAfter: now.Add(365 * 24 * time.Hour),
		KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true, DNSNames: []string{"localhost"},
		IPAddresses: append([]net.IP{net.ParseIP("127.0.0.1"), net.IPv6loopback}, ips...),
	}
	der, err := x509.CreateCertificate(rand.Reader, &tmpl, &tmpl, &key.PublicKey, key)
	if err != nil {
		return tls.Certificate{}, err
	}
	kb, _ := x509.MarshalECPrivateKey(key)
	crtPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: kb})
	os.WriteFile(crtPath, crtPEM, 0o600)
	os.WriteFile(keyPath, keyPEM, 0o600)
	return tls.X509KeyPair(crtPEM, keyPEM)
}

// ---------------------------------------------------------------- network --

func lanIPs() []net.IP {
	var out []net.IP
	seen := map[string]bool{}
	add := func(ip net.IP) {
		if ip4 := ip.To4(); ip4 != nil && !ip4.IsLoopback() && !ip4.IsLinkLocalUnicast() && !seen[ip4.String()] {
			seen[ip4.String()] = true
			out = append(out, ip4)
		}
	}
	// Primary route first (also works on Android 11+ where interface listing is blocked).
	if c, err := net.Dial("udp4", "8.8.8.8:80"); err == nil {
		if ua, ok := c.LocalAddr().(*net.UDPAddr); ok {
			add(ua.IP)
		}
		c.Close()
	}
	if ifs, err := net.Interfaces(); err == nil {
		for _, ifc := range ifs {
			if ifc.Flags&net.FlagUp == 0 || ifc.Flags&net.FlagLoopback != 0 {
				continue
			}
			addrs, _ := ifc.Addrs()
			for _, a := range addrs {
				if ipn, ok := a.(*net.IPNet); ok {
					add(ipn.IP)
				}
			}
		}
	}
	return out
}

func openBrowser(u string) {
	var cmd *exec.Cmd
	switch {
	case strings.Contains(os.Getenv("PREFIX"), "com.termux"):
		if p, err := exec.LookPath("termux-open-url"); err == nil {
			cmd = exec.Command(p, u)
		}
	case runtime.GOOS == "windows":
		cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", u)
	case runtime.GOOS == "darwin":
		cmd = exec.Command("open", u)
	default:
		if p, err := exec.LookPath("xdg-open"); err == nil {
			cmd = exec.Command(p, u)
		}
	}
	if cmd != nil {
		cmd.Start()
	}
}

// -------------------------------------------------------------------- main --

func main() {
	host, _ := os.Hostname()
	if host == "" {
		host = "Host"
	}
	port := flag.Int("port", 8443, "HTTPS port that other devices connect to")
	localPort := flag.Int("local-port", 8080, "loopback-only port for this device's own UI")
	ipFlag := flag.String("ip", "", "advertise this IP instead of auto-detecting")
	name := flag.String("name", host, "name of this device")
	noOpen := flag.Bool("no-open", false, "don't open the browser automatically")
	flag.Parse()

	var ips []net.IP
	if *ipFlag != "" {
		ip := net.ParseIP(*ipFlag)
		if ip == nil {
			log.Fatalf("invalid --ip %q", *ipFlag)
		}
		ips = []net.IP{ip}
	} else {
		ips = lanIPs()
	}
	if len(ips) == 0 {
		fmt.Println("! No network address found. Connect to Wi-Fi / start a hotspot, or pass --ip <address>.")
		ips = []net.IP{net.ParseIP("127.0.0.1")}
	}
	cert, err := loadOrCreateCert(ips)
	if err != nil {
		log.Fatalf("certificate error: %v", err)
	}
	fp := sha256.Sum256(cert.Certificate[0])

	h := &Hub{sessions: map[string]*Session{}, transfers: map[string]*Transfer{}, fails: map[string]*failRec{},
		token: randHex(16), hostKey: randHex(16), hostName: cleanName(*name, 40, "Host"),
		fp: strings.ToUpper(hex.EncodeToString(fp[:]))}
	for _, ip := range ips {
		h.addrs = append(h.addrs, net.JoinHostPort(ip.String(), strconv.Itoa(*port)))
	}

	sub, _ := fs.Sub(webFS, "web")
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/join", h.join)
	mux.HandleFunc("GET /api/me", h.me)
	mux.HandleFunc("GET /api/events", h.events)
	mux.HandleFunc("POST /api/approve", h.approve)
	mux.HandleFunc("POST /api/kick", h.kick)
	mux.HandleFunc("POST /api/rotate", h.rotate)
	mux.HandleFunc("GET /api/qr.png", h.qr)
	mux.HandleFunc("POST /api/offer", h.offer)
	mux.HandleFunc("POST /api/t/{id}/decline", h.decline)
	mux.HandleFunc("POST /api/t/{id}/cancel", h.cancel)
	mux.HandleFunc("PUT /api/t/{id}/chunk", h.putChunk)
	mux.HandleFunc("GET /api/t/{id}/dl", h.download)
	mux.HandleFunc("POST /api/text", h.text)
	mux.HandleFunc("POST /api/messages/clear", h.clearMessages)
	mux.Handle("GET /", http.FileServerFS(sub))

	quiet := log.New(io.Discard, "", 0)
	lanLn, err := net.Listen("tcp", fmt.Sprintf(":%d", *port))
	if err != nil {
		log.Fatalf("cannot listen on port %d: %v  (try --port)", *port, err)
	}
	locLn, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", *localPort))
	if err != nil {
		log.Fatalf("cannot listen on 127.0.0.1:%d: %v  (try --local-port)", *localPort, err)
	}
	lan := &http.Server{Handler: secure(mux, 0), ErrorLog: quiet, ReadHeaderTimeout: 10 * time.Second,
		IdleTimeout: 2 * time.Minute,
		TLSConfig:   &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS12}}
	loc := &http.Server{Handler: secure(mux, *localPort), ErrorLog: quiet, ReadHeaderTimeout: 10 * time.Second,
		IdleTimeout: 2 * time.Minute}
	go lan.ServeTLS(lanLn, "", "")
	go loc.Serve(locLn)
	go h.watchdog()

	hostURL := fmt.Sprintf("http://127.0.0.1:%d/?k=%s", *localPort, h.hostKey)
	invite := "https://" + h.addrs[0] + "/#j=" + h.token
	fmt.Println()
	fmt.Println("  FileDrop is running")
	fmt.Println("  -------------------")
	fmt.Println("  1) This device - open (your browser should open by itself):")
	fmt.Println("     " + hostURL)
	fmt.Println()
	fmt.Println("  2) Other devices - scan this QR code, or open the link:")
	if q, err := qrcode.New(invite, qrcode.Low); err == nil {
		fmt.Println(q.ToSmallString(false))
	}
	fmt.Println("     " + invite)
	fmt.Println()
	fmt.Println("  Their browser will warn about the self-signed certificate once -")
	fmt.Println("  choose Advanced > Proceed. You then approve each device here.")
	if len(h.addrs) > 1 {
		fmt.Println("  Other addresses: " + strings.Join(h.addrs[1:], ", "))
	}
	fmt.Println("\n  Press Ctrl+C to stop.")
	if !*noOpen {
		go func() { time.Sleep(500 * time.Millisecond); openBrowser(hostURL) }()
	}
	select {}
}
